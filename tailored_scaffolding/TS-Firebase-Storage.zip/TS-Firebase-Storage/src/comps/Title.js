import React from 'react';

const Title = () => {
  return (
    <div className="title">
      <h1>Tailored Scaffolding</h1>
      <h2>GALLERY</h2>
      <p>A showcase of our work for the past year or so!</p>
    </div>
  );
};

export default Title;
