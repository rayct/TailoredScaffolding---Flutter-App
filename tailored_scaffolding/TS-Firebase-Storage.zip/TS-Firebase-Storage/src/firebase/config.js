import * as firebase from 'firebase/app';
import 'firebase/storage';
import 'firebase/firestore';

var firebaseConfig = {
  apiKey: 'AIzaSyD-jaI8Ra6mqZnP3rpUJG6WokwoxUf2dxc',
  authDomain: 'tailored-scaffolding.firebaseapp.com',
  databaseURL: 'https://tailored-scaffolding.firebaseio.com',
  projectId: 'tailored-scaffolding',
  storageBucket: 'tailored-scaffolding.appspot.com',
  messagingSenderId: '533017448469',
  appId: '1:533017448469:web:edb98bf11e7a81bb72fe1c',
  measurementId: 'G-YXTKB88PHR',
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const projectStorage = firebase.storage();
const projectFirestore = firebase.firestore();
const timestamp = firebase.firestore.FieldValue.serverTimestamp;

export { projectStorage, projectFirestore, timestamp };
