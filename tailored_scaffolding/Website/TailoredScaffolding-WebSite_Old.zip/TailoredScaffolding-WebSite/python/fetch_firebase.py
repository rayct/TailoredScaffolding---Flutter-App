# import pyrebase

# config = {
#     "apiKey: "AIzaSyD-jaI8Ra6mqZnP3rpUJG6WokwoxUf2dxc",
#     "authDomain: "tailored-scaffolding.firebaseapp.com",
#     "databaseURL: "https://tailored-scaffolding.firebaseio.com",
#     "projectId: "tailored-scaffolding",
#     "storageBucket: "tailored-scaffolding.appspot.com",
#     "messagingSenderId: "533017448469",
#     "appId: "1:533017448469:web:edb98bf11e7a81bb72fe1c",
#     "measurementId: "G-YXTKB88PHR"

# }

# firebase = pyrebase.intialize_app(config)
# storage = firebase.storage()

# path_on_cloud = "photos/"
# path_local = ""
# storage.child(path_on_cloud).put(path_local)